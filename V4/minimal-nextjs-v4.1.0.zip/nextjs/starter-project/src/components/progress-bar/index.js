export { default as StyledProgressBar } from './styles';

export { default } from './ProgressBar';
