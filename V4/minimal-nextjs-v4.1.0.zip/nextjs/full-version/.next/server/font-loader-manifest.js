self.__FONT_LOADER_MANIFEST={
  "pages": {
    "/_app": [
      "static/media/6a44acd4f1e705fc.p.woff2",
      "static/media/83c76cede88902c5.p.woff2"
    ]
  },
  "app": {}
}